---
name: unknown issue template
about: Issue unknown
title: ''
labels: ''
assignees: ''

---

### Issue title

### Issue Description

### Versions:

- Browser(s):
- Nginx version:
- Operating system of web server running Nginx:

### Nginx config:
```
paste your nginx config here
```

### Screenshot(s):

[Screenshot(s) for difficult to describe visual issues are **mandatory**. Post links instead of **Inline Images** for Screenshots containing **Adult material**.]

### Settings:

- [List here all the changes you made to the default settings]

### Other optional information you want to add other than the above:
